import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { usuarioservice } from './usuarioservice';
@Injectable({ providedIn: 'root' })
export class adminservice {
  private readonly api = '/api/admin';
  constructor(
    private http: HttpClient,
    private auth: usuarioservice,
  ) {}
  getConfiguracion(): Observable<Record<string, unknown>> {
    return this.http.get<Record<string, unknown>>(`${this.api}/game-configuration`, {
      headers: this.auth.getHeaders(),
    });
  }
  actualizarConfiguracion(datos: Record<string, unknown>): Observable<unknown> {
    return this.http.put(`${this.api}/game-configuration`, datos, {
      headers: this.auth.getHeaders(),
    });
  }
}
