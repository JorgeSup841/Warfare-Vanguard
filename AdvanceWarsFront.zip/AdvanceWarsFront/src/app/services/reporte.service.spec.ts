import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';
import { ReporteService } from './reporte.service';

describe('ReporteService', () => {
  it('obtiene un PDF como blob a través del backend', () => {
    TestBed.configureTestingModule({providers:[provideHttpClient(),provideHttpClientTesting()]});
    const servicio=TestBed.inject(ReporteService);
    const http=TestBed.inject(HttpTestingController);
    servicio.obtener(11).subscribe(blob=>expect(blob instanceof Blob).toBe(true));
    const req=http.expectOne('/api/games/11/report.pdf');
    expect(req.request.method).toBe('GET');
    expect(req.request.responseType).toBe('blob');
    req.flush(new Blob(['%PDF-1.4'],{type:'application/pdf'}));
    http.verify();
  });
});
