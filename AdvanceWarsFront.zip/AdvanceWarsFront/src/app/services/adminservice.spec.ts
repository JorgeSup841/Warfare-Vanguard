import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting, HttpTestingController } from '@angular/common/http/testing';
import { adminservice } from './adminservice';

describe('adminservice', () => {
  it('consulta la configuración administrativa por REST', () => {
    TestBed.configureTestingModule({providers:[provideHttpClient(),provideHttpClientTesting()]});
    const api=TestBed.inject(adminservice);
    const http=TestBed.inject(HttpTestingController);
    api.getConfiguracion().subscribe(c=>expect(c).toEqual({}));
    const req=http.expectOne('/api/admin/game-configuration');
    expect(req.request.method).toBe('GET');
    req.flush({});
    http.verify();
  });
});
