import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { usuarioservice } from './usuarioservice';
describe('OTP login sin challenge visible', () => {
  let service: usuarioservice;
  let http: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(usuarioservice);
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());
  it('envía internamente challengeId junto al código', () => {
    service.prepararDesafio('login', { challengeId: 'desafio-prueba' });
    service.verificarLogin('123456').subscribe();
    const req = http.expectOne('/api/auth/verify-otp');
    expect(req.request.body).toEqual({ challengeId: 'desafio-prueba', code: '123456' });
    req.flush({
      accessToken: 'header.payload.signature',
      user: { id: 1, username: 'comandante', email: 'a@b.com', role: 'USER' },
    });
    expect(service.getRole()).toBe('USER');
  });
  it('no tiene sesión sin verificación', () => {
    expect(service.estaAutenticado()).toBe(false);
  });
});
