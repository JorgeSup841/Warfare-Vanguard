import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { tableroservice } from './tableroservice';
describe('tableroservice', () => {
  it('GET /map no crea otra partida', () => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    const api = TestBed.inject(tableroservice);
    const http = TestBed.inject(HttpTestingController);
    api.getTablero(42).subscribe();
    const req = http.expectOne('/api/games/42/map');
    expect(req.request.method).toBe('GET');
    req.flush({ gameId: 42, width: 2, height: 2, tiles: [] });
    http.verify();
  });
});
