import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  nuevapartida,
  partidaresumen,
  tablero,
  estadojuego,
  eventojuego,
  seleccionjugador,
  registrarasiento,
} from '../models/tablero';
import { usuarioservice } from './usuarioservice';

@Injectable({ providedIn: 'root' })
export class tableroservice {
  private readonly api = '/api/games';
  constructor(
    private http: HttpClient,
    private auth: usuarioservice,
  ) {}
  private headers(): HttpHeaders {
    return this.auth.getHeaders();
  }
  crearPartida(datos: nuevapartida): Observable<partidaresumen> {
    return this.http.post<partidaresumen>(this.api, datos, { headers: this.headers() });
  }
  listarPartidas(): Observable<partidaresumen[]> {
    return this.http.get<partidaresumen[]>(this.api, { headers: this.headers() });
  }
  getPartida(id: number): Observable<partidaresumen> {
    return this.http.get<partidaresumen>(`${this.api}/${id}`, { headers: this.headers() });
  }
  getTablero(id: number): Observable<tablero> {
    return this.http.get<tablero>(`${this.api}/${id}/map`, { headers: this.headers() });
  }
  getEstado(id: number): Observable<estadojuego> {
    return this.http.get<estadojuego>(`${this.api}/${id}/state`, { headers: this.headers() });
  }
  agregarJugador(id: number, datos: registrarasiento): Observable<unknown> {
    return this.http.post(`${this.api}/${id}/players`, datos, { headers: this.headers() });
  }
  seleccionarComandante(
    id: number,
    jugadorId: number,
    datos: seleccionjugador,
  ): Observable<unknown> {
    return this.http.put(`${this.api}/${id}/players/${jugadorId}/selection`, datos, {
      headers: this.headers(),
    });
  }
  iniciarPartida(id: number): Observable<unknown> {
    return this.http.post(`${this.api}/${id}/start`, {}, { headers: this.headers() });
  }
  mover(id: number, unidadId: number, x: number, y: number): Observable<unknown> {
    return this.http.post(
      `${this.api}/${id}/units/${unidadId}/move`,
      { x, y },
      { headers: this.headers() },
    );
  }
  atacar(id: number, unidadId: number, targetUnitId: number): Observable<unknown> {
    return this.http.post(
      `${this.api}/${id}/units/${unidadId}/attack`,
      { targetUnitId },
      { headers: this.headers() },
    );
  }
  capturar(id: number, unidadId: number): Observable<unknown> {
    return this.http.post(
      `${this.api}/${id}/units/${unidadId}/capture`,
      {},
      { headers: this.headers() },
    );
  }
  producir(
    id: number,
    propertyId: number,
    unitDefinitionId: number,
    spawnX: number,
    spawnY: number,
  ): Observable<unknown> {
    return this.http.post(
      `${this.api}/${id}/production`,
      { propertyId, unitDefinitionId, spawnX, spawnY },
      { headers: this.headers() },
    );
  }
  finTurno(id: number): Observable<unknown> {
    return this.http.post(`${this.api}/${id}/turn/end`, {}, { headers: this.headers() });
  }
  poder(id: number): Observable<unknown> {
    return this.http.post(`${this.api}/${id}/commanders/power`, {}, { headers: this.headers() });
  }
  getLogs(id: number): Observable<eventojuego[]> {
    return this.http.get<eventojuego[]>(`${this.api}/${id}/logs`, { headers: this.headers() });
  }
  descargarPDF(id: number): Observable<Blob> {
    return this.http.get(`${this.api}/${id}/report.pdf`, {
      headers: this.headers(),
      responseType: 'blob',
    });
  }
}
