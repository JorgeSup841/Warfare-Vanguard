import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import {
  registro,
  respuestapendiente,
  verificacion,
  respuestalogin,
  desafioautenticacion,
  usuario,
  usuarioautenticado,
  rolusuario,
} from '../models/usuario';

@Injectable({ providedIn: 'root' })
export class usuarioservice {
  private readonly api = '/api';
  private token: string | null = null;
  private usuarioActual: usuarioautenticado | null = null;
  private expira: number | null = null;
  private desafio: desafioautenticacion | null = null;
  private recuperacionId: string | null = null;
  private sesionSubject = new BehaviorSubject<usuarioautenticado | null>(null);
  readonly sesion$ = this.sesionSubject.asObservable();
  constructor(private http: HttpClient) {}

  registrar(datos: registro): Observable<respuestapendiente> {
    return this.http.post<respuestapendiente>(`${this.api}/auth/register`, datos);
  }
  iniciarSesion(datos: { username: string; password: string }): Observable<respuestapendiente> {
    return this.http.post<respuestapendiente>(`${this.api}/auth/login`, datos);
  }
  verificarCorreo(codigo: string): Observable<string> {
    const datos = this.datosCodigo(codigo, 'correo');
    return this.http.post(`${this.api}/auth/verify-email`, datos, { responseType: 'text' });
  }
  verificarLogin(codigo: string): Observable<respuestalogin> {
    const datos = this.datosCodigo(codigo, 'login');
    return this.http
      .post<respuestalogin>(`${this.api}/auth/verify-otp`, datos)
      .pipe(tap((respuesta) => this.guardarSesion(respuesta)));
  }
  reenviarCodigo(): Observable<respuestapendiente> {
    if (!this.desafio) throw new Error('No hay código pendiente. Vuelve a iniciar el proceso.');
    return this.http
      .post<respuestapendiente>(`${this.api}/auth/resend-otp`, {
        challengeId: this.desafio.challengeId,
      })
      .pipe(
        tap((respuesta) => {
          if (this.desafio)
            this.desafio = {
              ...this.desafio,
              challengeId: respuesta.challengeId,
              expiresAt: respuesta.expiresAt,
            };
        }),
      );
  }
  prepararDesafio(tipo: 'correo' | 'login', respuesta: respuestapendiente, correo?: string): void {
    if (!respuesta?.challengeId)
      throw new Error('La API no devolvió challengeId. Comprueba el DTO del backend.');
    this.desafio = {
      tipo,
      challengeId: respuesta.challengeId,
      correo,
      expiresAt: respuesta.expiresAt,
    };
  }
  getDesafio(): desafioautenticacion | null {
    return this.desafio;
  }
  limpiarDesafio(): void {
    this.desafio = null;
  }
  private datosCodigo(codigo: string, tipo: 'correo' | 'login'): verificacion {
    if (!this.desafio || this.desafio.tipo !== tipo)
      throw new Error('El proceso de verificación no está disponible.');
    return { challengeId: this.desafio.challengeId, code: codigo.trim() };
  }
  private guardarSesion(respuesta: respuestalogin): void {
    if (!respuesta.accessToken || !respuesta.user?.role)
      throw new Error('Respuesta de sesión incompleta.');
    // Solo memoria: sin localStorage y sin cookies creadas por Angular.
    this.token = respuesta.accessToken;
    this.usuarioActual = { ...respuesta.user, role: this.normalizarRol(respuesta.user.role) };
    this.expira = respuesta.expiresAt
      ? Date.parse(respuesta.expiresAt)
      : this.leerExpiracionJWT(respuesta.accessToken);
    this.desafio = null;
    this.sesionSubject.next(this.usuarioActual);
  }
  private leerExpiracionJWT(jwt: string): number | null {
    try {
      const payload = JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return typeof payload.exp === 'number' ? payload.exp * 1000 : null;
    } catch {
      return null;
    }
  }
  private normalizarRol(rol: string): rolusuario {
    return rol === 'ADMIN' || rol === 'ROLE_ADMIN' ? 'ADMIN' : 'USER';
  }
  getToken(): string | null {
    return this.estaAutenticado() ? this.token : null;
  }
  getUsuarioActual(): usuarioautenticado | null {
    return this.estaAutenticado() ? this.usuarioActual : null;
  }
  getRole(): rolusuario | null {
    const u = this.getUsuarioActual();
    return u ? this.normalizarRol(u.role) : null;
  }
  isAdmin(): boolean {
    return this.getRole() === 'ADMIN';
  }
  estaAutenticado(): boolean {
    if (!this.token || !this.usuarioActual) return false;
    if (this.expira !== null && Date.now() >= this.expira) {
      this.logout();
      return false;
    }
    return true;
  }
  logout(): void {
    this.token = null;
    this.usuarioActual = null;
    this.expira = null;
    this.desafio = null;
    this.recuperacionId = null;
    this.sesionSubject.next(null);
  }
  getHeaders(): HttpHeaders {
    const token = this.getToken();
    return token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders();
  }
  // Rutas previstas en el plan: verificar contra Swagger antes de habilitar CRUD.
  getUsuarios(): Observable<usuario[]> {
    return this.http.get<usuario[]>(`${this.api}/users`, { headers: this.getHeaders() });
  }
  getUsuarioById(id: number): Observable<usuario> {
    return this.http.get<usuario>(`${this.api}/users/${id}`, { headers: this.getHeaders() });
  }
  updateUsuario(id: number, datos: Partial<usuario>): Observable<usuario> {
    return this.http.put<usuario>(`${this.api}/users/${id}`, datos, { headers: this.getHeaders() });
  }
  getPerfil(): Observable<usuarioautenticado> {
    return this.http.get<usuarioautenticado>(`${this.api}/auth/me`, { headers: this.getHeaders() });
  }
  solicitarRecuperacion(email: string): Observable<unknown> {
    return this.http.post(`${this.api}/auth/forgot-password`, { email });
  }
  prepararRecuperacion(respuesta: unknown): boolean {
    if (
      respuesta &&
      typeof respuesta === 'object' &&
      'challengeId' in respuesta &&
      typeof respuesta.challengeId === 'string'
    ) {
      this.recuperacionId = respuesta.challengeId;
      return true;
    }
    return false;
  }
  restablecerPassword(code: string, newPassword: string): Observable<unknown> {
    if (!this.recuperacionId) throw new Error('El backend no devolvió un desafío de recuperación.');
    return this.http
      .post(`${this.api}/auth/reset-password`, {
        challengeId: this.recuperacionId,
        code,
        newPassword,
      })
      .pipe(
        tap(() => {
          this.recuperacionId = null;
        }),
      );
  }
}
