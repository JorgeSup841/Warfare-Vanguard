import { partida } from './partida';
export interface nuevapartida {
  playerNames: string[];
  width: number;
  height: number;
  seed: number;
}
export interface partidaresumen {
  id: number;
  status: 'SETUP' | 'IN_PROGRESS' | 'FINISHED' | string;
  playerCount?: number;
  width?: number;
  height?: number;
  seed?: number;
  playerNames?: string[];
}
export interface casillatablero {
  x: number;
  y: number;
  terrain: string;
  propertyType: string | null;
  ownerOrder: number | null;
}
export interface tablero {
  gameId: number;
  width: number;
  height: number;
  tiles: casillatablero[];
}
// Contrato propuesto: validar en Swagger antes de usar acciones y setup avanzados.
export type estadojuego = partida;
export interface seleccionjugador {
  factionId: number;
  commanderId: number;
}
export interface registrarasiento {
  name: string;
  turnOrder?: number;
}
export interface eventojuego {
  id?: number;
  eventType?: string;
  description?: string;
  occurredAt?: string;
}
