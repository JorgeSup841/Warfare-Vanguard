import { Component, AfterViewInit, ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import Phaser from 'phaser';
import { forkJoin, Subscription, Observable } from 'rxjs';
import { juegoservice } from '../../services/juegoservice';
import { tableroservice } from '../../services/tableroservice';
import { EscenaMapa, DatosEscena, TAM_CASILLA } from '../../phaser/escenamapa';
import { casilla, configuracionmapa, terreno, mapa, tipoterreno } from '../../models/mapa';
import { tablero, estadojuego, eventojuego } from '../../models/tablero';
import { ReporteService } from '../../services/reporte.service';

@Component({
  selector: 'app-juegocomponent',
  standalone: false,
  templateUrl: './juegocomponent.html',
  styleUrl: './juegocomponent.css',
})
export class Juegocomponent implements OnInit, AfterViewInit, OnDestroy {
  private phaser?: Phaser.Game;
  private subs = new Subscription();
  private viewLista = false;
  private pendingMap: tablero | null = null;
  readonly modoDemo: boolean;
  readonly id: number;
  configuracion: configuracionmapa | null = null;
  terrenos: terreno[] = [];
  cargando = true;
  error = '';
  mensaje = '';
  bloqueado = false;
  estado: estadojuego | null = null;
  logs: eventojuego[] = [];
  proporcion = '4 / 3';
  seleccion: { x: number; y: number; terreno?: terreno } | null = null;
  unidadId = 0;
  objetivoId = 0;
  x = 0;
  y = 0;
  propiedadId = 0;
  definicionId = 0;
  tiposMovimiento = [
    { codigo: 'FOOT', nombre: 'Infantería' },
    { codigo: 'MECH', nombre: 'Mecanizada' },
    { codigo: 'TREAD', nombre: 'Oruga' },
    { codigo: 'WHEEL', nombre: 'Ruedas' },
    { codigo: 'AIR', nombre: 'Aire' },
    { codigo: 'SHIP', nombre: 'Barco' },
  ];
  constructor(
    private ruta: ActivatedRoute,
    private catalogos: juegoservice,
    private api: tableroservice,
    private pdf: ReporteService,
    private cdr: ChangeDetectorRef,
  ) {
    this.modoDemo = Boolean(this.ruta.snapshot.data['demo']);
    this.id = Number(this.ruta.snapshot.paramMap.get('id')) || 0;
  }
  ngOnInit(): void {
    this.subs.add(
      forkJoin({
        terrenos: this.catalogos.getTerrenos(),
        config: this.catalogos.getConfiguracionMapa(),
      }).subscribe({
        next: (res) => {
          this.terrenos = res.terrenos;
          this.configuracion = res.config;
          if (this.modoDemo) this.dibujar(this.demoMap(res.config));
          else this.cargarMapa();
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.cargando = false;
          this.error = `Error al leer catálogos JSON (HTTP ${e.status || 0})`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  ngAfterViewInit(): void {
    this.viewLista = true;
    if (this.pendingMap) {
      const pending = this.pendingMap;
      this.pendingMap = null;
      this.dibujar(pending);
    }
  }
  cargarMapa(): void {
    if (this.modoDemo || !this.id) return;
    this.cargando = true;
    this.error = '';
    this.cdr.markForCheck();
    this.subs.add(
      this.api.getTablero(this.id).subscribe({
        next: (t) => {
          this.dibujar(t);
          this.cargarEstado();
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.cargando = false;
          this.error = `No se pudo consultar el mapa (HTTP ${e.status || 0}). Revisa GET /api/games/${this.id}/map y los permisos.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  private demoMap(config: configuracionmapa): tablero {
    const tiles: tablero['tiles'] = [];
    for (let y = 0; y < config.height; y++)
      for (let x = 0; x < config.width; x++) {
        let terrain = 'PLAIN';
        if (y === Math.floor(config.height / 2)) terrain = 'ROAD';
        else if ((x * 5 + y * 11) % 25 < 3) terrain = 'WATER';
        else if ((x * 7 + y * 3) % 19 < 4) terrain = 'FOREST';
        else if ((x * 13 + y * 7) % 37 < 3) terrain = 'MOUNTAIN';
        const hq =
          x === 1 && y === 1 ? 1 : x === config.width - 2 && y === config.height - 2 ? 2 : null;
        tiles.push({ x, y, terrain, propertyType: hq ? 'HEADQUARTERS' : null, ownerOrder: hq });
      }
    return { gameId: 0, width: config.width, height: config.height, tiles };
  }
  private dibujar(t: tablero): void {
    if (!this.viewLista) {
      this.pendingMap = t;
      return;
    }
    this.cargando = false;
    this.proporcion = `${t.width} / ${t.height}`;
    this.seleccion = null;
    this.cdr.markForCheck();
    const mapaEscena: mapa = {
      width: t.width,
      height: t.height,
      tiles: t.tiles.map((c) => ({ x: c.x, y: c.y, terrainType: c.terrain as tipoterreno })),
    };
    const bases = t.tiles
      .filter((c) => c.propertyType === 'HEADQUARTERS')
      .sort((a, b) => (a.ownerOrder ?? 0) - (b.ownerOrder ?? 0))
      .map((c) => ({ x: c.x, y: c.y }));
    const datos: DatosEscena = {
      mapa: mapaEscena,
      terrenos: this.terrenos,
      bases,
      alPasarSobre: (c: casilla | null) => this.alPasarSobre(c),
    };
    if (!this.phaser) {
      this.phaser = new Phaser.Game({
        type: Phaser.AUTO,
        parent: 'contenedor-juego',
        width: t.width * TAM_CASILLA,
        height: t.height * TAM_CASILLA,
        backgroundColor: '#14201a',
        scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.NO_CENTER },
        render: { pixelArt: true },
        scene: [],
      });
      this.phaser.scene.add('EscenaMapa', EscenaMapa, true, datos);
    } else this.phaser.scene.getScene('EscenaMapa')?.scene.restart(datos);
  }
  private alPasarSobre(c: casilla | null): void {
    const anterior = this.seleccion;
    if (!c) {
      if (this.seleccion) {
        this.seleccion = null;
        this.cdr.markForCheck();
      }
      return;
    }
    if (anterior?.x === c.x && anterior.y === c.y) return;
    this.seleccion = {
      x: c.x,
      y: c.y,
      terreno: this.terrenos.find((t) => t.terrainType === c.terrainType),
    };
    this.x = c.x;
    this.y = c.y;
    this.cdr.markForCheck();
  }
  costo(t: terreno, tipo: string): string {
    const valor = t.movementCost[tipo];
    return valor == null ? '—' : valor === 0 ? 'No pasa' : String(valor);
  }
  get unidadSeleccionada() {
    return (
      this.estado?.units?.find((u) => u.x === this.seleccion?.x && u.y === this.seleccion?.y) ||
      null
    );
  }
  cargarEstado(): void {
    if (this.modoDemo || !this.id) return;
    this.subs.add(
      this.api.getEstado(this.id).subscribe({
        next: (e) => {
          this.estado = e;
          this.mensaje = 'Estado autoritativo actualizado.';
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.estado = null;
          this.mensaje = `El motor aún no entrega /state (HTTP ${e.status || 0}). Puedes visualizar el mapa.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  cargarLogs(): void {
    if (this.modoDemo) return;
    this.subs.add(
      this.api.getLogs(this.id).subscribe({
        next: (logs) => {
          this.logs = Array.isArray(logs) ? logs : [];
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error = `Historial no disponible (HTTP ${e.status || 0}).`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  comando(tipo: 'mover' | 'atacar' | 'capturar' | 'producir' | 'turno' | 'poder'): void {
    if (this.bloqueado || this.modoDemo || !this.estado) {
      this.error = 'Para ejecutar acciones necesitas /state del backend y una partida real.';
      this.cdr.markForCheck();
      return;
    }
    const validId = (n: number) => Number.isSafeInteger(n) && n > 0;
    const validCoord = (n: number) => Number.isSafeInteger(n) && n >= 0;
    if (
      (['mover', 'atacar', 'capturar'].includes(tipo) && !validId(this.unidadId)) ||
      (tipo === 'atacar' && !validId(this.objetivoId)) ||
      (tipo === 'producir' && (!validId(this.propiedadId) || !validId(this.definicionId))) ||
      (tipo === 'mover' && (!validCoord(this.x) || !validCoord(this.y))) ||
      (tipo === 'producir' && (!validCoord(this.x) || !validCoord(this.y)))
    ) {
      this.error = 'Revisa los identificadores y coordenadas de la acción.';
      this.cdr.markForCheck();
      return;
    }
    if (
      (tipo === 'turno' || tipo === 'poder' || tipo === 'producir') &&
      !confirm(`¿Confirmar ${tipo}?`)
    )
      return;
    let peticion: Observable<unknown>;
    switch (tipo) {
      case 'mover':
        peticion = this.api.mover(this.id, this.unidadId, this.x, this.y);
        break;
      case 'atacar':
        peticion = this.api.atacar(this.id, this.unidadId, this.objetivoId);
        break;
      case 'capturar':
        peticion = this.api.capturar(this.id, this.unidadId);
        break;
      case 'producir':
        peticion = this.api.producir(this.id, this.propiedadId, this.definicionId, this.x, this.y);
        break;
      case 'turno':
        peticion = this.api.finTurno(this.id);
        break;
      case 'poder':
        peticion = this.api.poder(this.id);
        break;
    }
    this.bloqueado = true;
    this.error = '';
    this.mensaje = 'Procesando acción en el servidor...';
    this.cdr.markForCheck();
    this.subs.add(
      peticion.subscribe({
        next: () => {
          this.bloqueado = false;
          this.mensaje = 'Acción confirmada por el servidor. Consultando estado...';
          this.cargarEstado();
          this.cargarMapa();
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.bloqueado = false;
          this.error = `Acción rechazada o no disponible (HTTP ${e.status || 0}). No se aplicó un cambio local.`;
          this.cdr.markForCheck();
          if (e.status === 409 || e.status === 0) this.cargarEstado();
        },
      }),
    );
  }
  descargarPDF(): void {
    if (this.modoDemo || !this.id) return;
    this.subs.add(
      this.pdf.obtener(this.id).subscribe({
        next: (pdf) => {
          try {
            this.pdf.guardarArchivo(pdf, this.id);
          } catch (e) {
            this.error = e instanceof Error ? e.message : 'Archivo inválido.';
          }
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error = `Reporte no disponible (HTTP ${e.status || 0}).`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
    this.phaser?.destroy(true);
    this.phaser = undefined;
  }
}
