import { Component, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { usuarioservice } from '../../services/usuarioservice';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-recuperarcomponent',
  standalone: false,
  templateUrl: './recuperarcomponent.html',
  styleUrl: './recuperarcomponent.css',
})
export class Recuperarcomponent implements OnDestroy {
  ocupado = false;
  mensaje = '';
  error = '';
  modo: 'solicitar' | 'restablecer' = 'solicitar';
  private subs = new Subscription();
  constructor(
    private auth: usuarioservice,
    private cdr: ChangeDetectorRef,
  ) {}
  solicitar(email: string): void {
    if (this.ocupado || !email.trim()) return;
    this.ocupado = true;
    this.error = '';
    this.cdr.markForCheck();
    this.subs.add(
      this.auth.solicitarRecuperacion(email.trim()).subscribe({
        next: (r) => {
          this.ocupado = false;
          const disponible = this.auth.prepararRecuperacion(r);
          this.mensaje =
            'Si la cuenta existe, recibirás instrucciones en tu correo.' +
            (disponible
              ? ' Introduce el código recibido.'
              : ' El backend debe definir cómo entregar el identificador de recuperación para completar el proceso.');
          if (disponible) this.modo = 'restablecer';
          this.cdr.markForCheck();
        },
        error: () => {
          this.ocupado = false;
          this.error =
            'No se pudo procesar la solicitud. Confirma que el endpoint esté implementado.';
          this.cdr.markForCheck();
        },
      }),
    );
  }
  restablecer(codigo: string, clave: string): void {
    if (this.ocupado || !codigo.trim() || !clave) return;
    this.ocupado = true;
    this.error = '';
    this.cdr.markForCheck();
    this.subs.add(
      this.auth.restablecerPassword(codigo.trim(), clave).subscribe({
        next: () => {
          this.ocupado = false;
          this.mensaje = 'Si el código es válido, se actualizó la contraseña. Regresa al login.';
          this.cdr.markForCheck();
        },
        error: () => {
          this.ocupado = false;
          this.error = 'No se pudo cambiar la contraseña. Confirma el contrato de recuperación.';
          this.cdr.markForCheck();
        },
      }),
    );
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
