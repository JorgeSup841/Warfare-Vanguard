import { Component, ChangeDetectorRef, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { tableroservice } from '../../services/tableroservice';
import { ReporteService } from '../../services/reporte.service';
import { estadojuego, eventojuego } from '../../models/tablero';
@Component({
  selector: 'app-resultadoscomponent',
  standalone: false,
  templateUrl: './resultadoscomponent.html',
  styleUrl: './resultadoscomponent.css',
})
export class Resultadoscomponent implements OnInit, OnDestroy {
  id = 0;
  estado: estadojuego | null = null;
  logs: eventojuego[] = [];
  error = '';
  mensaje = '';
  cargando = false;
  private subs = new Subscription();
  constructor(
    private ruta: ActivatedRoute,
    private api: tableroservice,
    private pdf: ReporteService,
    private cdr: ChangeDetectorRef,
  ) {}
  ngOnInit(): void {
    this.id = Number(this.ruta.snapshot.paramMap.get('id'));
    this.cargar();
  }
  cargar(): void {
    this.cargando = true;
    this.subs.add(
      this.api.getEstado(this.id).subscribe({
        next: (e) => {
          this.estado = e;
          this.cargando = false;
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.cargando = false;
          this.error = `GET /state no disponible (HTTP ${e.status || 0})`;
          this.cdr.markForCheck();
        },
      }),
    );
    this.subs.add(
      this.api.getLogs(this.id).subscribe({
        next: (l) => {
          this.logs = Array.isArray(l) ? l : [];
          this.cdr.markForCheck();
        },
        error: () => {
          this.cdr.markForCheck();
        },
      }),
    );
  }
  descargar(): void {
    this.subs.add(
      this.pdf.obtener(this.id).subscribe({
        next: (blob) => {
          try {
            this.pdf.guardarArchivo(blob, this.id);
            this.mensaje = 'Descarga solicitada.';
          } catch (e) {
            this.error = e instanceof Error ? e.message : 'PDF inválido.';
          }
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error = `No se pudo descargar PDF (HTTP ${e.status || 0}).`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
