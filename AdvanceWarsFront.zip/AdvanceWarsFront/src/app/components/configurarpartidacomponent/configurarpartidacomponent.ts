import { Component, ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription, forkJoin } from 'rxjs';
import { tableroservice } from '../../services/tableroservice';
import { juegoservice } from '../../services/juegoservice';
import { partidaresumen } from '../../models/tablero';
import { faccion, comandante } from '../../models/partida';
@Component({
  selector: 'app-configurarpartidacomponent',
  standalone: false,
  templateUrl: './configurarpartidacomponent.html',
  styleUrl: './configurarpartidacomponent.css',
})
export class Configurarpartidacomponent implements OnInit, OnDestroy {
  id = 0;
  resumen: partidaresumen | null = null;
  facciones: faccion[] = [];
  comandantes: comandante[] = [];
  factionId = 0;
  commanderId = 0;
  playerId = 0;
  ocupado = false;
  error = '';
  mensaje = '';
  private sub = new Subscription();
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private api: tableroservice,
    private catalogs: juegoservice,
    private cdr: ChangeDetectorRef,
  ) {}
  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.sub.add(
      forkJoin({
        partida: this.api.getPartida(this.id),
        facciones: this.catalogs.getFacciones(),
        comandantes: this.catalogs.getComandantes(),
      }).subscribe({
        next: (r) => {
          this.resumen = r.partida;
          this.facciones = r.facciones;
          this.comandantes = r.comandantes;
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error = `Falta consultar configuración (HTTP ${e.status || 0}). Verificar GET /api/games/:id.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  get compatibles(): comandante[] {
    const f = this.facciones.find((x) => x.id === this.factionId);
    return this.comandantes.filter((c) => c.factionCode === f?.code);
  }
  guardarSeleccion(): void {
    if (
      this.ocupado ||
      ![this.playerId, this.factionId, this.commanderId].every(
        (n) => Number.isSafeInteger(n) && n > 0,
      )
    ) {
      this.error = 'Introduce IDs válidos del jugador, facción y comandante.';
      this.cdr.markForCheck();
      return;
    }
    const elegido = this.compatibles.some((c) => c.id === this.commanderId);
    if (!elegido) {
      this.error = 'El comandante debe pertenecer a la facción seleccionada.';
      this.cdr.markForCheck();
      return;
    }
    this.ocupado = true;
    this.error = '';
    this.sub.add(
      this.api
        .seleccionarComandante(this.id, this.playerId, {
          factionId: this.factionId,
          commanderId: this.commanderId,
        })
        .subscribe({
          next: () => {
            this.ocupado = false;
            this.mensaje = 'Selección enviada al servidor.';
            this.cdr.markForCheck();
          },
          error: (e) => {
            this.ocupado = false;
            this.error = `No se pudo guardar selección (HTTP ${e.status || 0}). Comprueba el DTO de /selection.`;
            this.cdr.markForCheck();
          },
        }),
    );
  }
  iniciar(): void {
    if (this.ocupado || !confirm('¿Iniciar esta partida?')) return;
    this.ocupado = true;
    this.error = '';
    this.sub.add(
      this.api.iniciarPartida(this.id).subscribe({
        next: () => {
          this.ocupado = false;
          void this.router.navigate(['/partidas', this.id, 'jugar']);
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.ocupado = false;
          this.error = `No se pudo iniciar (HTTP ${e.status || 0}). Configuración incompleta o endpoint no disponible.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
