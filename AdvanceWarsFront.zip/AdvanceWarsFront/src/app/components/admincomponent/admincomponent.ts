import { Component, ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { usuarioservice } from '../../services/usuarioservice';
import { adminservice } from '../../services/adminservice';
import { ReporteService } from '../../services/reporte.service';
import { usuario } from '../../models/usuario';
@Component({
  selector: 'app-admincomponent',
  standalone: false,
  templateUrl: './admincomponent.html',
  styleUrl: './admincomponent.css',
})
export class Admincomponent implements OnInit, OnDestroy {
  usuarios: usuario[] = [];
  configTexto = '';
  mensaje = '';
  error = '';
  procesando = false;
  idPDF = 0;
  private subs = new Subscription();
  constructor(
    private auth: usuarioservice,
    private admin: adminservice,
    private pdf: ReporteService,
    private cdr: ChangeDetectorRef,
  ) {}
  ngOnInit(): void {
    this.cargar();
  }
  cargar(): void {
    this.error = '';
    this.subs.add(
      this.auth.getUsuarios().subscribe({
        next: (res) => {
          this.usuarios = Array.isArray(res) ? res : [];
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error = `GET /api/users: HTTP ${e.status || 0}. Comprueba permisos ADMIN.`;
          this.cdr.markForCheck();
        },
      }),
    );
    this.subs.add(
      this.admin.getConfiguracion().subscribe({
        next: (c) => {
          this.configTexto = JSON.stringify(c, null, 2);
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.mensaje = `Configuración administrativa no disponible (HTTP ${e.status || 0}).`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  cambiarRol(u: usuario, nuevo: string): void {
    if (this.procesando || u.id == null || !['ADMIN', 'USER'].includes(nuevo) || u.role === nuevo)
      return;
    if (
      !confirm(`¿Cambiar el rol de ${u.username} a ${nuevo}? El backend debe validar la operación.`)
    )
      return;
    this.procesando = true;
    this.error = '';
    this.cdr.markForCheck();
    this.subs.add(
      this.auth.updateUsuario(u.id, { role: nuevo as 'ADMIN' | 'USER' }).subscribe({
        next: (actual) => {
          this.procesando = false;
          u.role = actual.role;
          this.mensaje = 'El backend confirmó el cambio de rol.';
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.procesando = false;
          this.error = `No fue posible cambiar rol (HTTP ${e.status || 0}). Revisa PUT /api/users/:id.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  guardarConfig(): void {
    if (this.procesando) return;
    let datos: Record<string, unknown>;
    try {
      const value: unknown = JSON.parse(this.configTexto);
      if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('La configuración debe ser un objeto JSON.');
      datos = value as Record<string, unknown>;
    } catch {
      this.error = 'Introduce un objeto JSON válido.';
      this.cdr.markForCheck();
      return;
    }
    if (!confirm('¿Enviar cambios de configuración al servidor?')) return;
    this.procesando = true;
    this.error = '';
    this.cdr.markForCheck();
    this.subs.add(
      this.admin.actualizarConfiguracion(datos).subscribe({
        next: () => {
          this.procesando = false;
          this.mensaje = 'Configuración aceptada por el servidor.';
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.procesando = false;
          this.error = `PUT configuración: HTTP ${e.status || 0}.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  pdfPartida(): void {
    if (!Number.isSafeInteger(this.idPDF) || this.idPDF <= 0) {
      this.error = 'Ingresa un ID válido.';
      this.cdr.markForCheck();
      return;
    }
    this.subs.add(
      this.pdf.obtener(this.idPDF).subscribe({
        next: (b) => {
          try {
            this.pdf.guardarArchivo(b, this.idPDF);
          } catch (e) {
            this.error = e instanceof Error ? e.message : 'PDF inválido.';
          }
          this.cdr.markForCheck();
        },
        error: (e) => {
          this.error = `PDF: HTTP ${e.status || 0}. Comprueba acceso al reporte.`;
          this.cdr.markForCheck();
        },
      }),
    );
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
